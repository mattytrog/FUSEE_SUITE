# Minerva Training Cell

### Custom Nvidia Tegra X1 DRAM trainer.

For more, check [Here](https://github.com/CTCaer/minerva_tc).



```
Minerva Training Cell (c) 2018 CTCaer.

/* Pain... And suffering. */
```
