/*
 * Copyright (c) 2018 naehrwert
 *
 * Copyright (c) 2018-2019 CTCaer
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "../common/memory_map.h"
#include "libs/compr/blz.h"

#include "gfx/di.h"
#include "gfx/gfx.h"
#include "gfx/tui.h"
#include "gfx/logos.h"

#include "libs/fatfs/ff.h"
#include "mem/heap.h"
#include "mem/sdram.h"
#include "power/max77620.h"
#include "power/bq24193.h"
#include "power/max17050.h"
#include "rtc/max77620-rtc.h"
#include "soc/fuse.h"
#include "soc/hw_init.h"
#include "soc/i2c.h"
#include "storage/sdmmc.h"
#include "utils/btn.h"
#include "utils/util.h"
#include "utils/rcm_usb.h"
#include "frontend/fe_emmc_tools.h"
sdmmc_t sd_sdmmc;
sdmmc_storage_t sd_storage;
FATFS sd_fs;
static bool sd_mounted;

#define max17050_item1 MAX17050_Current
#define max17050_item2 MAX17050_RepSOC
#define max17050_item3 MAX17050_AvgVCELL
#define BATT_THRESHDIS 5
#define BATT_THRESHDIS_mV 3500


//todo realign msg array. OOgly.
char msg[50][75] =
{
"START_OF_VARIABLES",																//0
"Entering menu",																	//1
"Release button",																	//2
"Cancelled. Skipped.                   ",											//3
"Booting",																			//4
"found.",																			//5
"not found.",																		//6
"Disabled Payloads:",																//7
"Press Any Key",																	//8
"Failed. Error ",																	//9
"Success.",																			//10
"Please select a payload number\nwith VOL+ and VOL-.\nPress PWR to confirm",		//11
"This will rename a payload to a number\n",											//12
"that you can choose with your chip.\n",											//13
"Your chip will always look for this\n",											//14
"until you change via VOL+ button\n",												//15
"This will permanently delete your file\n\n",										//16
"To cancel, choose Exit\n\n",														//17
"Renamed:",																			//18
"                                      ",											//19
"Powering off",																		//20
"Release PWR button", 																//21
"Attempting boot   ",																//22
"V6_090220",																		//23
"-END-",																			//24
};

char samdsettings[50][38] =
{
"ANIM02",																			//00
"SCREENSAVER1",																		//01
"payload.bin",																		//02
"payload1.bin",																		//03
"bootloader/update.bin",															//04
"payload.dis",																		//05
"payload1.dis",																		//06
"bootloader/update.dis",															//07
"JOYCON     ",																		//08
"VOLUME+    ",																		//09
"USB VOLTAGE",																		//10
"Chip-based autoRCM mode active.",													//11
"Boot Animation 1 selected.",														//12
"Screensaver is active.",															//13
"LOGO_ENABLED", 																	//14
{0xE6},																				//15
{0x00},																				//16
{0x12},																				//17
{0xFF},																				//18
{0xFF},																				//19
{0xFF},																				//20
"bootloader/bootlogo1.bmp",															//21
"bootloader/bootlogo.bmp",															//22
"bootloader/fusee_bootlogo_disabled",												//23
};

bool sd_mount()
{
	if (sd_mounted)
		return true;

	if (sdmmc_storage_init_sd(&sd_storage, &sd_sdmmc, SDMMC_1, SDMMC_BUS_WIDTH_4, 11))
	{
		int res = 0;
		res = f_mount(&sd_fs, "", 1);
		if (res == FR_OK)
		{
			sd_mounted = 1;
			return true;
		}
	}

	return false;
}

void sd_unmount()
{
	if (sd_mounted)
	{
		f_mount(NULL, "", 1);
		sdmmc_storage_end(&sd_storage);
		sd_mounted = false;
	}
}

void *sd_file_read(const char *path, u32 *fsize)
{
	FIL fp;
	if (f_open(&fp, path, FA_READ) != FR_OK)
		return NULL;

	u32 size = f_size(&fp);
	if (fsize)
		*fsize = size;

	void *buf = malloc(size);

	if (f_read(&fp, buf, size, NULL) != FR_OK)
	{
		free(buf);
		f_close(&fp);

		return NULL;
	}

	f_close(&fp);

	return buf;
}

int sd_save_to_file(void *buf, u32 size, const char *filename)
{
	FIL fp;
	u32 res = 0;
	res = f_open(&fp, filename, FA_CREATE_ALWAYS | FA_WRITE);
	if (res)
	{
		EPRINTFARGS("Error (%d) creating file\n%s.\n", res, filename);
		return res;
	}

	f_write(&fp, buf, size, NULL);
	f_close(&fp);

	return 0;
}

void emmcsn_path_impl(char *path, char *sub_dir, char *filename, sdmmc_storage_t *storage)
{
	sdmmc_storage_t storage2;
	sdmmc_t sdmmc;
	char emmcSN[9];
	bool init_done = false;

	memcpy(path, "backup", 7);
	f_mkdir(path);

	if (!storage)
	{
		if (!sdmmc_storage_init_mmc(&storage2, &sdmmc, SDMMC_4, SDMMC_BUS_WIDTH_8, 4))
			memcpy(emmcSN, "00000000", 9);
		else
		{
			init_done = true;
			itoa(storage2.cid.serial, emmcSN, 16);
		}
	}
	else
		itoa(storage->cid.serial, emmcSN, 16);

	u32 sub_dir_len = strlen(sub_dir);   // Can be a null-terminator.
	u32 filename_len = strlen(filename); // Can be a null-terminator.

	memcpy(path + strlen(path), "/", 2);
	memcpy(path + strlen(path), emmcSN, 9);
	f_mkdir(path);
	memcpy(path + strlen(path), sub_dir, sub_dir_len + 1);
	if (sub_dir_len)
		f_mkdir(path);
	memcpy(path + strlen(path), "/", 2);
	memcpy(path + strlen(path), filename, filename_len + 1);

	if (init_done)
		sdmmc_storage_end(&storage2);
}

void emmc_path_impl(char *path, char *sub_dir, char *filename, sdmmc_storage_t *storage)
{
	sdmmc_storage_t storage2;
	bool init_done = false;
	memcpy(path, "safe", 5);
	f_mkdir(path);
	

	if (storage)init_done = true;

	u32 sub_dir_len = strlen(sub_dir);   // Can be a null-terminator.
	u32 filename_len = strlen(filename); // Can be a null-terminator.

	memcpy(path + strlen(path), "/", 2);
	if (sub_dir_len){
	memcpy(path + strlen(path), sub_dir, sub_dir_len + 1);
	f_mkdir(path);
	memcpy(path + strlen(path), "/", 2);
	}
	memcpy(path + strlen(path), filename, filename_len + 1);

	if (init_done)
		sdmmc_storage_end(&storage2);
}

void check_power_off_from_hos()
{
	// Power off on AutoRCM wakeup from HOS shutdown. For modchips/dongles.
	u8 hosWakeup = i2c_recv_byte(I2C_5, MAX77620_I2C_ADDR, MAX77620_REG_IRQTOP);
	if (hosWakeup & MAX77620_IRQ_TOP_RTC_MASK)
	{
		sd_unmount();

		// Stop the alarm, in case we injected too fast.
		max77620_rtc_stop_alarm();
	}
}

// This is a safe and unused DRAM region for our payloads.
#define RELOC_META_OFF      0x7C
#define PATCHED_RELOC_SZ    0x94
#define PATCHED_RELOC_STACK 0x40007000
#define PATCHED_RELOC_ENTRY 0x40010000
#define EXT_PAYLOAD_ADDR    0xC03C0000
#define RCM_PAYLOAD_ADDR    (EXT_PAYLOAD_ADDR + ALIGN(PATCHED_RELOC_SZ, 0x10))
#define COREBOOT_ADDR       (0xD0000000 - 0x100000)
#define CBFS_DRAM_EN_ADDR   0x4003e000
#define  CBFS_DRAM_MAGIC    0x4452414D // "DRAM"

void reloc_patcher(u32 payload_dst, u32 payload_src, u32 payload_size)
{
	memcpy((u8 *)payload_src, (u8 *)IPL_LOAD_ADDR, PATCHED_RELOC_SZ);

	volatile reloc_meta_t *relocator = (reloc_meta_t *)(payload_src + RELOC_META_OFF);

	relocator->start = payload_dst - ALIGN(PATCHED_RELOC_SZ, 0x10);
	relocator->stack = PATCHED_RELOC_STACK;
	relocator->end   = payload_dst + payload_size;
	relocator->ep    = payload_dst;

	if (payload_size == 0x7000)
	{
		memcpy((u8 *)(payload_src + ALIGN(PATCHED_RELOC_SZ, 0x10)), (u8 *)COREBOOT_ADDR, 0x7000); //Bootblock
		*(vu32 *)CBFS_DRAM_EN_ADDR = CBFS_DRAM_MAGIC;
	}
}

bool render_boot_logo()
{
	
	static u8 *BOOTLOGO = NULL;
	
	//gfx_con_setpos (0,0);
	//gfx_clear_color(0xFF000000);
	
	bool bootlogoFound = false;

	struct _bmp_data
	{
		u32 size;
		u32 size_x;
		u32 size_y;
		u32 offset;
		u32 pos_x;
		u32 pos_y;
	};

	struct _bmp_data bmpData;
	if((!strcmp(samdsettings[14], "LOGO_DISABLE"))) return 0;
	if(!sd_mount()) return 0;
	if(!f_stat(samdsettings[23], NULL)) return 0;

	u8 *bitmap = NULL;
	bitmap = (u8 *)sd_file_read(samdsettings[21], NULL);

	if (!bitmap) bitmap = (u8 *)sd_file_read(samdsettings[22], NULL);
	
	if (!bitmap) return 0;
	else
			{
				// Get values manually to avoid unaligned access.
				bmpData.size = bitmap[2] | bitmap[3] << 8 |
					bitmap[4] << 16 | bitmap[5] << 24;
				bmpData.offset = bitmap[10] | bitmap[11] << 8 |
					bitmap[12] << 16 | bitmap[13] << 24;
				bmpData.size_x = bitmap[18] | bitmap[19] << 8 |
					bitmap[20] << 16 | bitmap[21] << 24;
				bmpData.size_y = bitmap[22] | bitmap[23] << 8 |
					bitmap[24] << 16 | bitmap[25] << 24;
				// Sanity check.
				if (bitmap[0] == 'B' &&
					bitmap[1] == 'M' &&
					bitmap[28] == 32)
				{
					if ((bmpData.size - bmpData.offset) <= 0x400000)
					{
						// Avoid unaligned access from BM 2-byte MAGIC and remove header.
						BOOTLOGO = (u8 *)malloc(0x400000);
						memcpy(BOOTLOGO, bitmap + bmpData.offset, bmpData.size - bmpData.offset);
						free(bitmap);
						// Center logo if res < 720x1280.
						bmpData.pos_x = (720  - bmpData.size_x) >> 1;
						bmpData.pos_y = (1280 - bmpData.size_y) >> 1;
						// Get background color from 1st pixel.
						if (bmpData.size_x < 720 || bmpData.size_y < 1280)
							gfx_clear_color(*(u32 *)BOOTLOGO);

						bootlogoFound = true;
					}
				}
				else
					free(bitmap);
			}

			// Render boot logo.
			if (bootlogoFound)
			{
				gfx_render_bmp_argb((u32 *)BOOTLOGO, bmpData.size_x, bmpData.size_y,
					bmpData.pos_x, bmpData.pos_y);
					return 1;
			}
		return 0;
}

int launch_payload(const char *path)
{


		FIL fp;
		f_open(&fp, path, FA_READ);
		

		// Read and copy the payload to our chosen address
		void *buf;
		u32 size = f_size(&fp);

		if (size < 0x30000)
			buf = (void *)RCM_PAYLOAD_ADDR;
		else
			buf = (void *)COREBOOT_ADDR;

		if (f_read(&fp, buf, size, NULL))
		{
			f_close(&fp);

			return 1;
		}

		f_close(&fp);
		//free(path);
		
		sd_unmount();

		if (size < 0x30000)
		{
			reloc_patcher(PATCHED_RELOC_ENTRY, EXT_PAYLOAD_ADDR, ALIGN(size, 0x10));

			reconfig_hw_workaround(false, byte_swap_32(*(u32 *)(buf + size - sizeof(u32))));
		}
		else
		{
			reloc_patcher(PATCHED_RELOC_ENTRY, EXT_PAYLOAD_ADDR, 0x7000);
			reconfig_hw_workaround(true, 0);
		}

		void (*ext_payload_ptr)() = (void *)EXT_PAYLOAD_ADDR;

		msleep(100);

		// Launch our payload.
		(*ext_payload_ptr)();
	gfx_clear_color(0xFF000000);
	gfx_con_setpos(0, 0);
	return 1;
}

void browse_file()
{
	char *file_sec = NULL;
	if (sd_mount())
	{
		file_sec = file_browser("", ".bin", "Select A Payload", false, false, true);
		if (!file_sec) return;
	}

if (file_sec) launch_payload(file_sec);
	sd_unmount();
	return;
}

void new_payload_file(const char *old_file_sec)
{
	char * file_sec;
	file_sec = (char * ) calloc('0', 256);
	char *new_file_sec = malloc(256);
	if (sd_mount())
	{
		file_sec = file_browser("", "", "Select A Payload", false, false, true);
		if (!file_sec) return;
	}
	
	memcpy (new_file_sec, old_file_sec, strlen(old_file_sec) + 1);
	if((!f_stat(old_file_sec, NULL)))
	{
		while ((!f_stat(new_file_sec, NULL)))
		{
			memcpy (new_file_sec+strlen(new_file_sec), ".old", 5);
		}
	}
	u8 fr = 0;
	fr = f_rename(old_file_sec, new_file_sec);
	if(!fr) gfx_printf("%s %s\n\nto %s\n\n", msg[18], old_file_sec, new_file_sec);
	msleep(1000);
	fr = 0;
	fr = f_rename(file_sec, old_file_sec);
	if(fr) gfx_printf("Failed renaming\n%s\nto %s\n\n", file_sec, old_file_sec);
	else gfx_printf("Renamed \n%s\nto %s\n\n", file_sec, old_file_sec);
	gfx_printf("\n\n%s", msg[8]);
	btn_wait();
	return;
}

void set_x_payload()
{
	char *file_sec = NULL;
	u8 fr = 0;
	int payloadnumber = 0;
	if (sd_mount())
	{
		file_sec = file_browser("", ".bin", "Select A Payload", false, false, true);
		if (!file_sec) return;
	}

if (file_sec) {
	gfx_printf("\n%k%s%s%s%s%k\n", 0xFFFFFF00, msg[12], msg[13], msg[14], msg[15],0xFF00FFFF);
	gfx_printf("%k%s\n\n\n",0xFFFFFFFF, msg[11]);
	gfx_con_getpos(&gfx_con.savedx, &gfx_con.savedy);
	}
	while(true)
	{
		gfx_con_setpos(gfx_con.savedx, gfx_con.savedy);
		if (payloadnumber !=0) gfx_printf("%kpayload%d.bin   %k", 0xFF00FF00, payloadnumber,  0xFFFFFFFF);
		else gfx_printf("%kCancel        ", 0xFF00FFFF);
		u8 btn = btn_wait(BTN_POWER | BTN_VOL_UP | BTN_VOL_DOWN);
		if(btn & BTN_POWER) break;
		if(btn & BTN_VOL_UP) ++payloadnumber;
		if(btn & BTN_VOL_DOWN) --payloadnumber;
		if (payloadnumber>8)payloadnumber = 0;
		if (payloadnumber<0)payloadnumber = 8;
	}
	if(payloadnumber == 0) goto out;
		else if(payloadnumber == 1) fr = f_rename (file_sec, "payload1.bin");
		else if(payloadnumber == 2) fr = f_rename (file_sec, "payload2.bin");
		else if(payloadnumber == 3) fr = f_rename (file_sec, "payload3.bin");
		else if(payloadnumber == 4) fr = f_rename (file_sec, "payload4.bin");
		else if(payloadnumber == 5) fr = f_rename (file_sec, "payload5.bin");
		else if(payloadnumber == 6) fr = f_rename (file_sec, "payload6.bin");
		else if(payloadnumber == 7) fr = f_rename (file_sec, "payload7.bin");
		else if(payloadnumber == 8) fr = f_rename (file_sec, "payload8.bin");
	if(fr) {gfx_printf("\n%k%s %d%k", 0xFFFF0000, msg[9], fr, 0xFFFFFFFF); payloadnumber = 0; goto out;}
	else gfx_printf("\n%k%s%k", 0xFF00FF00, msg[10], 0xFFFFFFFF);
	msleep(500);
	
out:
gfx_printf("\n\n%k%s%k", 0xFFFFFF00, msg[8], 0xFFFFFFFF);
btn_wait();
	if(payloadnumber == 0)
	sd_unmount();
	return;
}

void disable_payload_file(const char *old_file_sec, const char *new_file_sec)
{
	u8 fr = 0;
	if (!sd_mount()) {fr = 1; goto out;}
	
	fr = f_rename(old_file_sec, new_file_sec);
out:
	if(fr) gfx_printf("\n%s %d", msg[9], fr);
	else gfx_printf("\n%s\n\n", msg[10]);
	msleep(1000);
	gfx_printf("\n\n%s", msg[8]);
	btn_wait();
	return;
}

void enable_payload_file(const char *old_file_sec, const char *new_file_sec)
{
	u8 fr = 0;
	if (!sd_mount()) {fr = 1; goto out;}
	
	fr = f_rename(old_file_sec, new_file_sec);
out:
	if(fr) gfx_printf("\n%s %d", msg[9], fr);
	else gfx_printf("\n%s\n\n", msg[10]);
	msleep(1000);
	gfx_printf("\n\n%s", msg[8]);
	btn_wait();
	return;
}

void delete_file()
{
	char * file_sec;
	file_sec = (char * ) calloc('0', 256);
	gfx_printf("%s%s%s", msg[16], msg[17], msg[8]);
	btn_wait();
	if (sd_mount())
	{
		file_sec = file_browser("", "", "This will permanently delete your file", false, false, true);
		if (!file_sec) return;
	}
	gfx_printf("Are you sure? [PWR] Yes, [VOL] Cancel");
	u8 btn = btn_wait(BTN_POWER | BTN_VOL_UP | BTN_VOL_DOWN);
		if(!(btn & BTN_POWER)) return;
	u8 fr = 0;
	fr = f_unlink(file_sec);
	if(!fr) gfx_printf("\n%s\n\n", msg[10]);
	else gfx_printf("\n%s %d", msg[9], fr);
	msleep(1000);
	gfx_printf("\n\n%s", msg[8]);
	btn_wait();
	return;
}

const char* path1 = (samdsettings[2]);
const char* path2 = (samdsettings[3]);
const char* path3 = (samdsettings[4]);
const char* bmppath1 = (msg[24]);
const char* bmppath2 = (msg[27]);
const char* bmppath3 = (msg[25]);
const char* bmppath4 = (msg[28]);
const char* bmppath5 = (msg[26]);
const char* bmppath6 = (msg[29]);
const char* dis1 = (samdsettings[5]);
const char* dis2 = (samdsettings[6]);
const char* dis3 = (samdsettings[7]);

void new_payload_bin_file(){new_payload_file (path1);}
void new_payload1_bin_file(){new_payload_file (path2);}
void new_update_bin_file(){f_mkdir("bootloader"); new_payload_file (path3);}
void new_payloadx_bin_file(){set_x_payload();}
void disable_payload_bin_file(){disable_payload_file(path1, dis1);}
void disable_payload1_bin_file(){disable_payload_file(path2, dis2);}
void disable_update_bin_file(){disable_payload_file(path3, dis3);}
void enable_payload_bin_file(){disable_payload_file(dis1, path1);}
void enable_payload1_bin_file(){disable_payload_file(dis2, path2);}
void enable_update_bin_file(){disable_payload_file(dis3, path3);}
void payload_status()
{
if(!sd_mount()) {gfx_printf("\nSD not mounted\n"); btn_wait(); return;}
gfx_printf("%k\n%s (primary) ", 0xFFFFFF00, path1);
if(!f_stat(path1, NULL)) gfx_printf ("%k%s%k\n", 0xFF00FF00, msg[5],0xFFFFFFFF);
	else gfx_printf ("%k%s%k\n", 0xFFFF0000,  msg[6],0xFFFFFFFF);

gfx_printf("%k\n%s (secondary) ", 0xFFFFFF00, path2);
if(!f_stat(path2, NULL)) gfx_printf ("%k%s%k\n", 0xFF00FF00, msg[5],0xFFFFFFFF);
	else gfx_printf ("%k%s%k\n", 0xFFFF0000,  msg[6],0xFFFFFFFF);

gfx_printf("%k\n%s (last) ", 0xFFFFFF00, path3);
if(!f_stat(path3, NULL)) gfx_printf ("%k%s%k\n", 0xFF00FF00, msg[5],0xFFFFFFFF);
	else gfx_printf ("%k%s%k\n", 0xFFFF0000,  msg[6],0xFFFFFFFF);
	
gfx_printf("%k\n%s\n", 0xFF00FFFF, msg[7]);
gfx_printf("%k\n%s ", 0xFFFFFF00, dis1);
if(!f_stat(dis1, NULL)) gfx_printf ("%k%s%k\n", 0xFF00FF00, msg[5],0xFFFFFFFF);
	else gfx_printf ("%k%s%k\n", 0xFFFF0000,  msg[6],0xFFFFFFFF);

gfx_printf("%k\n%s ", 0xFFFFFF00, dis2);
if(!f_stat(dis2, NULL)) gfx_printf ("%k%s%k\n", 0xFF00FF00, msg[5],0xFFFFFFFF);
	else gfx_printf ("%k%s%k\n", 0xFFFF0000,  msg[6],0xFFFFFFFF);

gfx_printf("%k\n%s ", 0xFFFFFF00, dis3);
if(!f_stat(dis3, NULL)) gfx_printf ("%k%s%k\n", 0xFF00FF00, msg[5],0xFFFFFFFF);
	else gfx_printf ("%k%s%k\n", 0xFFFF0000,  msg[6],0xFFFFFFFF);
btn_wait();
}


ment_t ment_restore[] = {
	MDEF_BACK(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("---- Essential -----", 0xFF0AB9E6),
	MDEF_HANDLER("Restore safe folder BOOT0/1", restore_emmc_quick),
	MDEF_HANDLER("Restore safe folder PRODINFO", restore_emmc_quick_prodinfo),
	MDEF_CHGLINE(),
	MDEF_CAPTION("------ Full --------", 0xFF0AB9E6),
	MDEF_HANDLER("Restore eMMC BOOT0/1", restore_emmc_boot),
	MDEF_HANDLER("Restore eMMC RAW GPP", restore_emmc_rawnand),
	MDEF_CHGLINE(),
	MDEF_CAPTION("-- GPP Partitions --", 0xFF0AB9E6),
	MDEF_HANDLER("Restore GPP partitions", restore_emmc_gpp_parts),
	MDEF_CHGLINE(),
	MDEF_CAPTION("---- Dangerous -----", 0xFF0AB9E6),
	MDEF_HANDLER("Restore BOOT0/1 without size check", restore_emmc_quick_noszchk),
	MDEF_END()
};

menu_t menu_restore = { ment_restore, "Restore Options", 0, 0 };

ment_t ment_backup[] = {
	MDEF_BACK(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("---- Essential -----", 0xFF0AB9E6),
	MDEF_HANDLER("Backup BOOT0/1/PRODINFO to safe folder", dump_emmc_quick),
	MDEF_CHGLINE(),
	MDEF_CAPTION("------ Full --------", 0xFF0AB9E6),
	MDEF_HANDLER("Backup eMMC BOOT0/1", dump_emmc_boot),
	MDEF_HANDLER("Backup eMMC RAW GPP", dump_emmc_rawnand),
	MDEF_CHGLINE(),
	MDEF_CAPTION("-- GPP Partitions --", 0xFF0AB9E6),
	MDEF_HANDLER("Backup eMMC SYS", dump_emmc_system),
	MDEF_HANDLER("Backup eMMC USER", dump_emmc_user),
	MDEF_END()
};

menu_t menu_backup = { ment_backup, "Backup Options", 0, 0 };

ment_t ment_plmanagement[] = {
	MDEF_BACK(),
	MDEF_CHGLINE(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("----- Status -----", 0xFF0AB9E6),
	MDEF_HANDLER("Payload Status", payload_status),
	MDEF_CHGLINE(),
	MDEF_CAPTION("-- Rename File To---", 0xFF0AB9E6),
	MDEF_HANDLER(samdsettings[2], new_payload_bin_file),
	MDEF_HANDLER(samdsettings[3], new_payload1_bin_file),
	MDEF_HANDLER("payloadx.bin (1 - 8) for SAMD select", new_payloadx_bin_file),
	MDEF_HANDLER("bootloader/update.bin", new_update_bin_file),
	MDEF_CHGLINE(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("----- Disable -----", 0xFF0AB9E6),
	MDEF_HANDLER(samdsettings[2], disable_payload_bin_file),
	MDEF_HANDLER(samdsettings[3], disable_payload1_bin_file),
	MDEF_HANDLER(samdsettings[4], disable_update_bin_file),
	MDEF_CHGLINE(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("----- Enable -----", 0xFF0AB9E6),
	MDEF_HANDLER(samdsettings[2], enable_payload_bin_file),
	MDEF_HANDLER(samdsettings[3], enable_payload1_bin_file),
	MDEF_HANDLER(samdsettings[4], enable_update_bin_file),
	MDEF_CHGLINE(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("----- Delete -----", 0xFF0AB9E6),
	MDEF_HANDLER("Delete file", delete_file),
	MDEF_END()
};

menu_t menu_plmanagement = { ment_plmanagement, "Payload Management", 0, 0 };

ment_t ment_main[] = {
	MDEF_BACK(),
	MDEF_CHGLINE(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("----- Browse -----", 0xFF0AB9E6),
	MDEF_HANDLER("Browse for payload", browse_file),
	MDEF_CHGLINE(),
	MDEF_CAPTION("---- Payloads ----", 0xFF0AB9E6),
	MDEF_MENU("Payload Management", &menu_plmanagement),
	MDEF_CHGLINE(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("--Backup/Restore--", 0xFF0AB9E6),
	MDEF_MENU("Backup Options", &menu_backup),
	MDEF_MENU("Restore Options", &menu_restore),
	MDEF_CHGLINE(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("------ SXOS ------", 0xFF0AB9E6),
	MDEF_HANDLER("Regenerate SXOS license.dat", restore_license_dat),
	MDEF_CHGLINE(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("----- Update -----", 0xFF0AB9E6),
	MDEF_HANDLER("SAMD21 Update mode", restore_septprimary_dat),
	MDEF_CHGLINE(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("------ Mount -----", 0xFF0AB9E6),
	MDEF_HANDLER("USB mount (Tidy_Memloader)", reboot_memloader),
	MDEF_CHGLINE(),
	MDEF_CHGLINE(),
	MDEF_CAPTION("------ Power -----", 0xFF0AB9E6),
	MDEF_HANDLER("Power Off", power_off),
	MDEF_END()
};

menu_t menu_main = { ment_main, "Fusee Suite SAMD21 prebootloader", 0, 0 };

void launch()
{
	tui_do_menu(&menu_main);
}

void fill_batt_asset(int segcol, int battPercentage, int battmVolts)
{
	int co = 0; int bk = 0;
	int battsegy = 35;
	//manual logarithmic(ish). Hardcoded for speed
	
	if(battPercentage > 1 && battPercentage < 6) {co = 1; bk = (40 - co); segcol +=2;}
	if(battPercentage > 5 && battPercentage < 11) {co = 2; bk = (40 - co); segcol +=2;}
	if(battPercentage > 10 && battPercentage < 16) {co = 4; bk = (40 - co);segcol +=2;}
	if(battPercentage > 15 && battPercentage < 21) {co = 6; bk = (40 - co);}
	if(battPercentage > 20 && battPercentage < 26) {co = 8; bk = (40 - co);}
	if(battPercentage > 25 && battPercentage < 31) {co = 10; bk = (40 - co);}
	if(battPercentage > 30 && battPercentage < 36) {co = 12; bk = (40 - co);}
	if(battPercentage > 35 && battPercentage < 41) {co = 14; bk = (40 - co);}
	if(battPercentage > 40 && battPercentage < 46) {co = 16; bk = (40 - co);}
	if(battPercentage > 45 && battPercentage < 51) {co = 18; bk = (40 - co);}
	if(battPercentage > 50 && battPercentage < 56) {co = 20; bk = (40 - co);}
	if(battPercentage > 55 && battPercentage < 61) {co = 22; bk = (40 - co);}
	if(battPercentage > 60 && battPercentage < 66) {co = 24; bk = (40 - co);}
	if(battPercentage > 65 && battPercentage < 71) {co = 26; bk = (40 - co);}
	if(battPercentage > 70 && battPercentage < 76) {co = 28; bk = (40 - co);}
	if(battPercentage > 75 && battPercentage < 81) {co = 30; bk = (40 - co);}
	if(battPercentage > 80 && battPercentage < 86) {co = 32; bk = (40 - co);}
	if(battPercentage > 85 && battPercentage < 91) {co = 34; bk = (40 - co);}
	if(battPercentage > 90 && battPercentage < 96) {co = 36; bk = (40 - co);}
	if(battPercentage > 95 && battPercentage < 100) {co = 38; bk = (40 - co);}
	if(battPercentage > 99) co = 40;

	for (int j = 1; j <= co; j++)
		{
			battsegy += 1;
			if (segcol == 0) gfx_set_rect_rgb(BATTDKGNASSET, 18,1, 36,battsegy);
			if (segcol == 1) gfx_set_rect_rgb(BATTGRNASSET, 18,1, 36,battsegy);
			if (segcol == 2) gfx_set_rect_rgb(BATTDKRDASSET, 18,1, 36,battsegy);
			if (segcol == 3) gfx_set_rect_rgb(BATTREDASSET, 18,1, 36,battsegy);
			
			
		}
	if(co!=40)
	{		
		for (int j = co; j <= bk; j++)
			{
			battsegy += 1;
			gfx_set_rect_rgb(BATTBLKASSET, 18,1, 36,battsegy);
			}
		battsegy = 35;
	}

	gfx_con_setpos(132, 36);
	gfx_printf("%K%k%d%% %dmV   ", 0xFF000000, 0xFFFFFFFF, battPercentage, battmVolts);
	
	if (segcol == 1) gfx_set_rect_grey(LNASSET, 17,11, 36,100);
	else gfx_set_rect_grey(LNOFFASSET, 17,11, 36,100);
}

void draw_outline_assets(bool includebtn)
{
	u8 * BTNASSET = (void *)malloc(0x32A0);
	u8 battoly = 32;
		
		gfx_set_rect_grey(BATTBTMASSET, 26,4, 32,battoly);
		battoly +=3;
		for (int i = 0; i<40; ++i)
		{
			++battoly;
			gfx_set_rect_grey(BATTSIDASSET, 26,1, 32,battoly);
		}
		gfx_set_rect_grey(BATTTOPASSET, 26,8, 32,battoly+1);
		blz_uncompress_srcdest(BUTTONASSET_blz, SZ_BUTTONASSET_blz, BTNASSET, SZ_BUTTONASSET);
		if(includebtn) gfx_set_rect_grey(BTNASSET, 32, 405, 688,0);
}

int interrupt_controller(const char * text1, const char * optional1, const char * text3, const char * text4, const u32 bgcolor, const u32 fgcolor)
{
	
	int drawn = 1;
	int res = 0;
	
	while (true)
	{
		if (drawn == 39)
			{
				gfx_con_setpos(32, 36);
				gfx_printf("%K%s", bgcolor, msg[19]);
			}
		if (drawn == 40)
			{
				gfx_con_setpos(32, 36);
				gfx_printf("%K%k%s %s...2", bgcolor, fgcolor, text1, optional1);
			}
		if (drawn == 79)
			{
				gfx_con_setpos(32, 36);
				gfx_printf("%K%s", bgcolor, msg[19]);
			}
		if (drawn == 80)
			{
				gfx_con_setpos(32, 36);
				gfx_printf("%K%k%s %s...1", bgcolor, fgcolor, text1, optional1);
			}
		gfx_con_setpos(112 , 72);
		gfx_printf("%K%k | ", bgcolor, fgcolor);
		gfx_con_setpos(192 , 72);
		gfx_printf("%K%k | ", bgcolor, fgcolor);
		gfx_con_setpos(256 , 72);
		gfx_printf("%K%k | ", bgcolor, fgcolor);
		gfx_con_setpos(16+(drawn*2) , 72);
		gfx_printf("%K%k >", bgcolor, fgcolor);
		
		u8 btn = btn_wait_timeout(20, BTN_POWER | BTN_VOL_UP | BTN_VOL_DOWN);
		
		if((btn & BTN_POWER) || (btn & BTN_VOL_UP)|| (btn & BTN_VOL_DOWN)) ++drawn;
		if(btn & BTN_POWER) res = 1;
		if(btn & BTN_VOL_UP) res = 2;
		if(btn & BTN_VOL_DOWN) res = 3;
		if(res && (!(btn & BTN_POWER)) && (!(btn & BTN_VOL_UP)) && (!(btn & BTN_VOL_DOWN))) {res = 4; break;}
		if(drawn > 120)break;
		
	}
	if (drawn > 120)
	{
		gfx_con_setpos(32, 36);
		gfx_printf("%s", (msg[19]));
		gfx_con_setpos(32, 36);
		gfx_printf("%K%k%s", bgcolor, fgcolor, text3);
		msleep(1000);
		gfx_con_setpos(32, 36);
		gfx_printf("%s", (msg[19]));
		goto out;
	}
	else
	{
	
		gfx_con_setpos(32, 36);
		gfx_printf("%K%k%s",bgcolor, fgcolor, text4);
		msleep(1000);
		gfx_con_setpos(32, 36);
		gfx_printf("%s", (msg[19]));
	}
out:		
	return res;
	
}

u8 screensaver()

{
	u8 brightness = 8;
	display_backlight_brightness(brightness, 1000);
	if((strcmp(samdsettings[1], "SCREENSAVER1"))) return brightness;
	u8 * ASSET = (void *)malloc(0x16698);
	u8 * CLR_SCREEN = (void *)malloc(0xF);
	u32 SCREENSAVER_TIMER = 0;
	u32 colour32 = 0; static bool flipx = false; static bool flipy = false;
	blz_uncompress_bootlogo(0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, NINTENDOASSET_blz, SZ_NINTENDOASSET_blz, ASSET, SZ_NINTENDOASSET);
		//swap col byte 3 for 1 and 1 for 3
		memcpy (CLR_SCREEN+0, ASSET + 2, 3);
		memcpy (CLR_SCREEN+1, ASSET + 1, 3);
		memcpy (CLR_SCREEN+2, ASSET + 0, 3);
		
		colour32 = (*(u32 *)CLR_SCREEN);
		gfx_clear_color(colour32);
		u32 xcord = 462; u32 ycord = 305; int dirx = 1; int diry = 1;
		u8 btn;
	while (true)
	{
		gfx_set_rect_rgb(ASSET, 90, 340, ycord,xcord);
		if(flipx) xcord = xcord + dirx;
		else xcord = xcord - dirx;
		
		if(flipy) ycord = ycord + diry;
		else ycord = ycord - diry;
		if(xcord >= 940) {flipx = false; ++dirx;}
		if(xcord <= 0) {flipx = true; ++dirx;}
		if(ycord >= 630) {flipy = false; ++diry;}
		if(ycord <= 0) {flipy = true; ++diry;}
		if(dirx>1) dirx = 1;
		if(diry>1) diry = 1;
		btn = btn_wait_timeout(0, BTN_POWER | BTN_VOL_UP | BTN_VOL_DOWN);
		if ((btn & BTN_POWER) || (btn & BTN_VOL_UP) || (btn & BTN_VOL_DOWN)) break;	
		++SCREENSAVER_TIMER;
		if(SCREENSAVER_TIMER == 20000) {display_backlight_brightness(0, 1000); check_power_off_from_hos(); power_off();}//2min timeout
	}
	brightness = 64;
	display_backlight_brightness(0, 1000);
	gfx_clear_color(0xFF000000);
	msleep(500);
	display_backlight_brightness(brightness, 100);
	
	return brightness;	
		
}

int perform_boot_animation(u8 selection)
{
	u8 btn;
	u8 * ASSET = (void *)malloc(0x16698);
	u8 * CLR_SCREEN = (void *)malloc(0xF);
	char TXT_COLOUR[3];
	u32 colour32 = 0;
	static bool bootlogoExists = false;
	u8 interruptres = 0;
	
	colour32 = (0xFF000000);
	TXT_COLOUR[0] = 0xFF;
	TXT_COLOUR[1] = 0xFF;
	TXT_COLOUR[2] = 0xFF;
	u32 movegfy; u32 limitgfy;
	
	
	if(selection == 2) {movegfy = 150; limitgfy = 305;}
	else if(selection == 3) {movegfy = 1; limitgfy = 340;}
	else if(selection == 4) {movegfy = 1; limitgfy = 90;}
	else {movegfy = 305; limitgfy = 305;} 
	
	btn = btn_wait_timeout(0, BTN_POWER | BTN_VOL_UP | BTN_VOL_DOWN);
			if (btn & BTN_POWER)
			{
				display_backlight_brightness(0, 100);
				gfx_clear_color(colour32);
				display_backlight_brightness(64, 100);
				interruptres=(interrupt_controller(msg[1], "", msg[2], msg[3], colour32, *(u32 *)TXT_COLOUR));
				
		
			}
			if (btn & BTN_VOL_UP)
			{
				display_backlight_brightness(0, 100);
				gfx_clear_color(colour32);
				display_backlight_brightness(64, 100);
				interruptres=(interrupt_controller(msg[4], samdsettings[3], msg[2], msg[3], colour32, *(u32 *)TXT_COLOUR));
			}
			
			if (btn & BTN_VOL_DOWN)
			{
				display_backlight_brightness(0, 100);
				gfx_clear_color(colour32);
				display_backlight_brightness(64, 100);
				interruptres=(interrupt_controller(msg[4], samdsettings[4], msg[2], msg[3], colour32, *(u32 *)TXT_COLOUR));
			}
			
			if (selection == 0) goto out;
			if (!interruptres)
			{
				display_backlight_brightness(0, 100);
				gfx_clear_color(colour32);
			} else goto out;
			
		bootlogoExists = render_boot_logo();
		
		if(!bootlogoExists)
		{			
			blz_uncompress_bootlogo(*(u8*)samdsettings[18], *(u8*)samdsettings[19], *(u8*)samdsettings[20], *(u8*)samdsettings[15], *(u8*)samdsettings[16], *(u8*)samdsettings[17], NINTENDOASSET_blz, SZ_NINTENDOASSET_blz, ASSET, SZ_NINTENDOASSET);
			//swap col byte 3 for 1 and 1 for 3
			memcpy (CLR_SCREEN+0, ASSET + 2, 3);
			memcpy (CLR_SCREEN+1, ASSET + 1, 3);
			memcpy (CLR_SCREEN+2, ASSET + 0, 3);	
			colour32 = (*(u32 *)CLR_SCREEN);
			TXT_COLOUR[0] = *(u8*)samdsettings[18];
			TXT_COLOUR[1] = *(u8*)samdsettings[19];
			TXT_COLOUR[2] = *(u8*)samdsettings[20];
			gfx_clear_color(colour32); 
			display_backlight_brightness(64, 100); // backlight on
			
			while (movegfy <=limitgfy)
			{

					if(selection == 1) gfx_set_rect_rgb(ASSET, 90, 340, 305 ,462);
					if(selection == 2) gfx_set_rect_rgb(ASSET, 90, 340, movegfy ,462);
					if(selection == 3) gfx_set_rect_rgb(ASSET, 90, movegfy, 305 ,462);
					if(selection == 4) gfx_set_rect_rgb(ASSET, movegfy, 340, 305 ,462);
					
				
			movegfy = (-(~movegfy));
			}
		} else
		{
			//gfx_clear_color(colour32); 
			display_backlight_brightness(250, 1000); // backlight on
		}
		btn = btn_wait_timeout(1000, BTN_POWER | BTN_VOL_UP | BTN_VOL_DOWN);
			if (btn & BTN_POWER)
			{
				if(bootlogoExists)
				{
				display_backlight_brightness(0, 1000);
				gfx_clear_color(colour32);
				}
				display_backlight_brightness(64, 100);
				interruptres=(interrupt_controller(msg[1], "", msg[2], msg[3], colour32, *(u32 *)TXT_COLOUR));
				
		
			}
			if (btn & BTN_VOL_UP)
			{
				if(bootlogoExists)
				{
				display_backlight_brightness(0, 1000);
				gfx_clear_color(colour32);
				}
				display_backlight_brightness(0, 1000);
				gfx_clear_color(colour32);
				display_backlight_brightness(64, 100);
				interruptres=(interrupt_controller(msg[4], samdsettings[3], msg[2], msg[3], colour32, *(u32 *)TXT_COLOUR));
			}
			
			if (btn & BTN_VOL_DOWN)
			{
				if(bootlogoExists)
				{
				display_backlight_brightness(0, 1000);
				gfx_clear_color(colour32);
				}
				display_backlight_brightness(0, 1000);
				gfx_clear_color(colour32);
				display_backlight_brightness(64, 100);
				interruptres=(interrupt_controller(msg[4], samdsettings[4], msg[2], msg[3], colour32, *(u32 *)TXT_COLOUR));
			}
			
			if (interruptres) goto out;
			
			
		
out:

return interruptres;		

}

void draw_sd_asset(bool sdonoff)
{
	u8 * SDASSET = (void *)malloc(0xE40);
		if (sdonoff) blz_uncompress_sdasset(0x00, 0xFF, 0x00, SDASSET_blz, SZ_SDASSET_blz, SDASSET, SZ_SDASSET);
		else blz_uncompress_sdasset(0xFF, 0x00, 0x00, SDASSET_blz, SZ_SDASSET_blz, SDASSET, SZ_SDASSET);
		gfx_set_rect_rgb(SDASSET, 32,38, 32,1210);
	
	
}

bool boot_payloads()
{
	
	if((!f_stat(path1, NULL))) launch_payload (path1);
	else if((!f_stat(path2, NULL))) launch_payload (path2);
		else if((!f_stat(path3, NULL))) launch_payload (path3);
	sd_unmount();
	return false;
}

void draw_rcm_asset(bool first_boot)
{


	gfx_clear_color(0xFF000000);
	static int battPercentage, battPercent,  battmV;
	while (true)
	{
		max17050_get_property(max17050_item2, (int *)&battPercent);
		max17050_get_property(max17050_item3, (int *)&battmV);
		battPercentage = ((battPercent >> 8) & 0xFF);
		static const char information[] =
		"%K%kFusee_UF2 Information. %s.\n"
		"\nBattery: %d%% %dmV   \n\n\n"
		"%kFollowing Straps Detected:\n\n\n\n"
		"%k%s\n"
		"\n\n"
		"%s\n"
		"\n\n"
		"%s\n"
		"\n\n"
		"%s\n"
		"\n\n\n\n%s\n\n%s\n%s\n"
		"\n"
		"%kName your payload(s) as follows:\n"
		"\n"
		"Location: SD Root.\n\n"
		"%s\n"
		"%s\n"
		"%s\n"
		"\n\nFor Kosmos users:\n\n"
		"%s%k\n\n";

	gfx_con_setpos(0, 0);
	gfx_printf(information,  0xFF000000, 0xFFFFFF00, msg[23], battPercentage, battmV, 0xFF00FF00, 0xFFFFFF00, samdsettings[8], samdsettings[9], samdsettings[10], samdsettings[11], samdsettings[12],samdsettings[13],msg[19], 0xFF00FFFF, samdsettings[2], samdsettings[3], samdsettings[4], samdsettings[4], 0xFFCCCCCC);
	//gfx_set_rect_grey(CTRLASSET, 41, 404, 679,0);
	if(!first_boot)
	{
		u8 btn = btn_wait_timeout(1000, BTN_POWER | BTN_VOL_UP | BTN_VOL_DOWN);
		if(!(btn & BTN_VOL_DOWN)) break;
	} else {msleep(1000); btn_wait(); break;}
	}
	gfx_clear_color(0xFF000000);
	gfx_con_setpos(0, 0);
	
}

const char * animated = (samdsettings[0]);//this is for arduino. char array easier to find than bits!

void boot_batt()
{
	//first, determine if battery is too flat  to boot.
	static int battPercentage, battPercent, Current,  battmV;
	static int bootStatus = 0; int newbootStatus = 0; u16 tickTimer = 0; u16 shutdownTimer = 0;
	static bool charging = 0; static bool refresh = 0; static int current_anim = 0;
	static u8 brightness = 64;
	u8 btn;
	max17050_get_property(max17050_item2, (int *)&battPercent);
	max17050_get_property(max17050_item3, (int *)&battmV);
	
	battPercentage = ((battPercent >> 8) & 0xFF);
	

	if (battmV >= BATT_THRESHDIS_mV && battPercentage >= BATT_THRESHDIS) bootStatus = 1;
	
	if(!bootStatus)
	{
		//draw batt outline
		draw_outline_assets(false);
		while (true)
		{
			max17050_get_property(max17050_item1, &Current);
			max17050_get_property(max17050_item2, (int *)&battPercent);
			max17050_get_property(max17050_item3, (int *)&battmV);
			battPercentage = ((battPercent >> 8) & 0xFF);
			if(Current>0) {charging = 1; tickTimer = 0;}
				else charging = 0;
			if (battmV >= BATT_THRESHDIS_mV && battPercentage >= BATT_THRESHDIS) break;
			else ++tickTimer;
			
			
			fill_batt_asset(charging, battPercentage, battmV);
			display_backlight_brightness(64, 100); // backlight on
			msleep(1000);
			if(!charging && tickTimer == 10) power_off();
		}
	}
	else
	{
		if((!strcmp(animated, "ANIM04"))) current_anim = 4;
		if((!strcmp(animated, "ANIM03"))) current_anim = 3;
		if((!strcmp(animated, "ANIM02"))) current_anim = 2;
		if((!strcmp(animated, "ANIM01"))) current_anim = 1;
		if((!strcmp(animated, "ANIM00"))) current_anim = 0;
		newbootStatus = perform_boot_animation(current_anim);
		//gfx_printf("%d", newbootStatus); btn_wait();
		display_backlight_brightness(0, 100); // backlight on
	}
	
	if (newbootStatus == 4)
	{
		newbootStatus = 0;
	}
	
	if(!newbootStatus)
	{
		sd_mount();
		boot_payloads();
		newbootStatus = 1;
	}

restart:
	
	if (newbootStatus == 1)
	{
		gfx_clear_color(0xFF000000);
		display_backlight_brightness(64, 100); // backlight on
	}
start:
	
	if (newbootStatus == 1)
	{
		tickTimer = 0; shutdownTimer = 0;
		draw_outline_assets(true);
		
		//build interface screen
		while(true)
		{
			max17050_get_property(max17050_item1, &Current);
			max17050_get_property(max17050_item2, (int *)&battPercent);
			max17050_get_property(max17050_item3, (int *)&battmV);
			battPercentage = ((battPercent >> 8) & 0xFF);
			if(Current>0) {charging = 1;}
				else charging = 0;
			fill_batt_asset(charging, battPercentage, battmV);
			if(refresh)
			{
				if(sd_mount()) {draw_sd_asset(true); sd_unmount();}
				else draw_sd_asset(false);
				refresh = false;
			}
			
			btn = btn_wait_timeout(0, BTN_POWER | BTN_VOL_UP | BTN_VOL_DOWN);
			if (btn & BTN_VOL_UP){gfx_clear_color(0xFF000000); display_backlight_brightness(brightness, 1000); launch(); gfx_clear_color(0xFF000000); msleep(250); refresh = true; newbootStatus = 1; goto start;}//draw batt outline
			if (btn & BTN_VOL_DOWN){gfx_clear_color(0xFF000000); display_backlight_brightness(brightness, 1000); draw_rcm_asset(false); gfx_clear_color(0xFF000000); msleep(250); refresh = true; newbootStatus = 1; goto start;}
			if (btn & BTN_POWER) 
			{	
				gfx_clear_color(0xFF000000);
				display_backlight_brightness(brightness, 1000);
				if (interrupt_controller(msg[20], "", msg[21], msg[22], 0xFF000000, 0xFFFFFFFF) == 1){display_backlight_brightness(0, 1000); check_power_off_from_hos(); power_off();}
				else {sd_mount(); boot_payloads(); check_power_off_from_hos(); power_off();}
			}
			msleep(1); ++tickTimer; ++shutdownTimer;
			if(tickTimer >= 500) {refresh = true; tickTimer = 0;}
			if(shutdownTimer >= 9000 && charging) {screensaver(); refresh = true; newbootStatus = 1; goto start;}
			if(shutdownTimer >= 9000 && !charging) {check_power_off_from_hos(); power_off();}
		}
		
	}
	
	if(newbootStatus==2)
	{
		sd_mount();
		if((!f_stat(path2, NULL))) launch_payload (path2);
		brightness = 64; newbootStatus = 1; goto restart;
	}
	
	if(newbootStatus==3)
	{
		sd_mount();
		if((!f_stat(path3, NULL))) launch_payload (path3);
		brightness = 64; newbootStatus = 1; goto restart;
	}
	
		
}
	

extern void pivot_stack(u32 stack_top);
void ipl_main()
{
	// Do initial HW configuration. This is compatible with consecutive reruns without a reset.
	config_hw();

	//Pivot the stack so we have enough space.
	pivot_stack(IPL_STACK_TOP);

	//Tegra/Horizon configuration goes to 0x80000000+, package2 goes to 0xA9800000, we place our heap in between.
	heap_init(IPL_HEAP_START);

	display_init();

	u32 *fb = display_init_framebuffer();
	gfx_init_ctxt(fb, 1280, 720, 720);

	gfx_con_init();

	display_backlight_pwm_init();
	while (true)
	boot_batt();
	
	while (true)
	;
}
